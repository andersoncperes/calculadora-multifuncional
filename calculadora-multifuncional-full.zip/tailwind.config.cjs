/** @type {import('tailwindcss').Config} */
module.exports = {
  darkMode: 'class',
  content: [
    "./index.html",
    "./src/**/*.{js,jsx,ts,tsx}"
  ],
  theme: { extend: { fontFamily: { sans: ['Inter','Roboto','ui-sans-serif','system-ui'] }, colors: { primary: { DEFAULT: '#2563eb' } } } },
  plugins: []
};