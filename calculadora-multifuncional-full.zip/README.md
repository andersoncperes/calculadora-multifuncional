# Calculadora Multifuncional

Projeto Vite + React + Tailwind (modo dark pronto).

Como usar:
1. Extraia o zip.
2. Abra a pasta no terminal.
3. Rode `npm install`.
4. Rode `npm run dev` e abra http://localhost:5173
